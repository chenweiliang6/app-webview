<!--
 * @Author: 19994643173 1075005842@qq.com
 * @Date: 2024-07-15 19:18:41
 * @LastEditors: 19994643173 1075005842@qq.com
 * @LastEditTime: 2024-07-15 19:52:10
 * @FilePath: \中建移动端\yidongduan\src\App.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <router-view></router-view>
</template>

<script setup>

</script>

<style>
#app {
  /* font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px; */
  font-size: 14px;
  width: 100%;
  height: 100%;
}
</style>
